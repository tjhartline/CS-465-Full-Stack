const mongoose = require('mongoose');
const host = process.env.DB_HOST || '127.0.0.1'
const dbURI = `mongodb://${host}/travlr`;
const fs = require('fs');
const path = require('path');

// Define the path to the trips.json file
const tripsFilePath = path.join(__dirname, '../data/trips.json');

// Read the contents of trips.json file
const tripsData = fs.readFileSync(tripsFilePath, 'utf8');

// Parse the JSON data
const trips = JSON.parse(tripsData);

// avoid 'current server discovery and monitoring engine is deprecated' warning
mongoose.set('useUnifiedTopology', true);

const connect = () => {
    setTimeout(() => mongoose.connect(dbURI, {
        useNewUrlParser: true,
        useCreateIndex: true
    }), 1000);
}

mongoose.connection.on('connected', () => {
});

mongoose.connection.on('error', err => {
});

mongoose.connection.on('disconnected', () => {
});

if (process.platform === 'win32') {
};

const gracefulShutdown = (msg, callback) => {
};

// For nodemon restarts
process.once('SIGUSR2', () => {
});

// For app termination
process.on('SIGINT', () => {
});

// For Heroku app termination
process.on('SIGTERM', () => {
});

connect();
// BRING IN YOUR SCHEMAS & MODELS
require('./travlr');
/*
require('./users');
require('./reviews');
require('./bookings');
require('./trips');
require('./locations');
require('./comments');
require('./photos');
require('./videos');
require('./tags');
require('./categories');
require('./subcategories');
require('./features');
require('./amenities');
require('./services');
require('./events');
require('./notifications');
require('./messages');
require('./conversations');
*/

